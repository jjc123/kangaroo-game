/*
 * This class is for the horizontally moving enemy.
 */
package kangarooGame;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.util.Duration;
import java.awt.Rectangle;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Jordan Clay
 */
public class Enemy1 {
    private Timeline animation;
    private double xCenter = 0;
    private double yCenter = 0;
    private Image graphics = new Image("file:enemy1.gif");
    private ImageView graphicsView = new ImageView(graphics);
    private boolean offScreen = false;
    public Enemy1() {
    }
    public Enemy1(double xCenter,double yCenter) {
        this.xCenter = xCenter;
        this.yCenter = yCenter;
        graphicsView.setLayoutX(xCenter);
        graphicsView.setLayoutY(yCenter);
    }
    /**
     * This method will set the center x-coordinate to a value.
     * 
     * PreCondition: The xCenter variable has been declared.
     * PostCondition: The xCenter variable has been set to a value.
     * 
     * @param xCenter - the center x-coordinate
     */
    public void setXCenter(double xCenter) {
        this.xCenter = xCenter;
    }
    /**
     * This method will return the value of the center x-coordinate.
     * 
     * PreCondition: The xCenter variable has been set.
     * PostCondition: The value of the center x-coordinate has been returned.
     * 
     * @return the value of the center x-coordinate
     */
    public double getXCenter() {
        return this.xCenter;
    }
    /**
     * This method will set the center y-coordinate to a value.
     * 
     * PreCondition: The yCenter variable has been declared.
     * PostCondition: The yCenter variable has been set to a value.
     * 
     * @param yCenter - the center y-coordinate
     */
    public void setYCenter(double yCenter) {
        this.yCenter = yCenter;
    }
    /**
     * This method will return the value of the center y-coordinate.
     * 
     * PreCondition: The yCenter variable has been set.
     * PostCondition: The value of the center y-coordinate has been returned.
     * 
     * @return the value of the center y-coordinate
     */
    public double getYCenter() {
        return this.yCenter;
    }
    /**
     * This method will set the x coordinate.
     * 
     * PreCondition: None PostCondition: The x coordinate is set.
     * 
     * @param layoutX - the x coordinate of this enemy
     */
    public void setLayoutX(double layoutX) {
        graphicsView.setLayoutX(layoutX);
    }
    /**
     * This method will return the x coordinate.
     * 
     * PreCondition: None PostCondition: The x coordinate is returned.
     * 
     * @return the x coordinate of this enemy
     */
    public double getLayoutX() {
        return graphicsView.getLayoutX();
    }
    /**
     * This method will set the y coordinate.
     * 
     * PreCondition: None PostCondition: The y coordinate is set.
     * 
     * @param layoutY - the y coordinate of this enemy
     */
    public void setLayoutY(double layoutY) {
        graphicsView.setLayoutY(layoutY);
    }
    /**
     * This method will return the y coordinate.
     * 
     * PreCondition: None PostCondition: The y coordinate is returned.
     * 
     * @return the y coordinate of this enemy
     */
    public double getLayoutY() {
        return graphicsView.getLayoutY();
    }
    /**
     * This method will return the ImageView object for the enemy.
     * 
     * PreCondition: None
     * PostCondition: The ImageView object for the enemy has been
     * returned.
     * 
     * @return the ImageView object for the enemy
     */
    public ImageView getGraphicsView() {
        return graphicsView;
    }
    /**
     * This method will return a boolean value of whether or not the enemy
     * is off the screen.
     * 
     * PreCondition: None PostCondition: The boolean value of whether or not
     * the enemy is off the screen has been returned.
     * 
     * @return a boolean value of whether or not the enemy is off the screen
     */
    public boolean getOffScreen() {
        return offScreen;
    }
    /**
     * This method will set a boolean value of whether or not the enemy
     * is off the screen.
     * 
     * PreCondition: None PostCondition: The boolean value of whether or not
     * the enemy is off the screen has been set.
     * 
     * @param offScreen - whether or not the enemy is off the screen
     */
    public void setOffScreen(boolean offScreen) {
        this.offScreen = offScreen;
    }
    
    /**
     * This method will play the animation of the enemy moving.
     * 
     * PreCondition: None.
     * PostCondition: The animation has been played.
     * 
     */
    public void animation() throws IOException {
        animation = new Timeline(
            //multiplying by 7 because that was determined to be the slowest speed at which an enemy was avoidable
            new KeyFrame(Duration.millis(1.0 + Math.random() * 7 + Math.random() * 7), e -> {
            try {
                move();
            } catch (IOException ex) {
                
            }
        }));
        animation.setCycleCount(Timeline.INDEFINITE);
        animation.play();
    }
    /**
     * This method will make the enemy move.
     * 
     * PreCondition: None
     * PostCondtion: The enemy is moving.
     * 
     */
    public void move() throws IOException {
        KangarooGame.collision1();
        KangarooGame.avoid();
        graphicsView.setLayoutX(graphicsView.getLayoutX() - 1);
    }
    /**
     * This method will return a bounds rectangle for the enemy.
     * 
     * PreCondition: None PostCondition: The bounds rectangle has been returned.
     * 
     * @return the bounds rectangle
     */
    public Rectangle getRectangle() {
        return new Rectangle((int)graphicsView.getLayoutX(),(int)graphicsView.getLayoutY(),40,30);
    }
    /**
     * This method will stop the enemy animation.
     * 
     * PreCondition: The animation is running. PostCondition: The animation
     * has stopped.
     * 
     */
    public void stop() {
        animation.stop();
    }
    /**
     * This method will use a random number to determine which image to use
     * for this enemy.
     * 
     * PreCondition: None PostCondition: The image has been set.
     * 
     */
    public void changeGraphics() {
        double randomNumber = Math.random();
        if (randomNumber >= 0.5) {
            graphicsView.setImage(new Image("file:enemy1.gif"));
        }
        else {
            graphicsView.setImage(new Image("file:enemy1B.gif"));
        }
    }
}
