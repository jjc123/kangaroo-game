/*
 * This a game where the player must use a button to jump
 * over birds and missiles.
 */
package kangarooGame;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.scene.layout.Pane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.io.*;
import java.util.*;
import static javafx.application.Application.launch;

/**
 * Jordan Clay
 */
public class KangarooGame extends Application {

    private static Player player = new Player(50, 220);
    private static Enemy1 enemy1 = new Enemy1(500, 220);
    private static Enemy2 enemy2 = new Enemy2(-500, -220);
    private static Button jumpButton = new Button("Jump");
    private static TextField scoreField = new TextField();
    private static TextField highScoreField = new TextField();
    private static int score = 0;
    private static int highScore = 0;
    private static boolean hasLost = false;

    @Override
    public void start(Stage primaryStage) throws IOException {
        Pane pane = new Pane();
        Image background = new Image("file:background.png");
        if (nightCheck()) {
            background = new Image("file:backgroundN.png");
        }
        pane.getChildren().add(new ImageView(background));
        pane.getChildren().add(player.getGraphicsView());
        pane.getChildren().add(enemy1.getGraphicsView());
        enemy1.animation();
        pane.getChildren().add(enemy2.getGraphicsView());
        enemy2.animation();
        jumpButton.setOnAction(new JumpHandler());
        jumpButton.setLayoutX(180);
        jumpButton.setLayoutY(350);
        pane.getChildren().add(jumpButton);
        Label scoreLabel = new Label("Score:");
        scoreLabel.setLayoutX(0);
        scoreLabel.setLayoutY(380);
        pane.getChildren().add(scoreLabel);
        scoreField.setLayoutX(35);
        scoreField.setLayoutY(380);
        pane.getChildren().add(scoreField);
        scoreField.setEditable(false);
        scoreField.setText(score + "");
        loadHighScore();
        Label highScoreLabel = new Label("High Score:");
        highScoreLabel.setLayoutX(190);
        highScoreLabel.setLayoutY(380);
        pane.getChildren().add(highScoreLabel);
        highScoreField.setLayoutX(255);
        highScoreField.setLayoutY(380);
        pane.getChildren().add(highScoreField);
        highScoreField.setEditable(false);
        
        //music, which is an original called "On the Cliff" written
        //for this game
        Media music = new Media(new File("music.mp3").toURI().toString());
        MediaPlayer musicPlayer = new MediaPlayer(music);
        musicPlayer.play();

        Scene scene = new Scene(pane, 400, 400);

        primaryStage.setTitle("Jumper");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    class JumpHandler implements EventHandler<ActionEvent> {

        public void handle(ActionEvent e) {
            player.animation();
        }
    }

    public static void collision1() throws IOException {
        if (player.getRectangle().intersects(enemy1.getRectangle())) {
            hasLost = true;
            scoreField.setText("You lose");
        }
    }

    public static void collision2() throws IOException {
        if (player.getRectangle().intersects(enemy2.getRectangle())) {
            hasLost = true;
            scoreField.setText("You lose");
        }
    }

    /**
     * This method will set the score.
     *
     * PreCondition: None PostCondition: The score has been set.
     *
     * @param newScore - the number to which to set the score
     */
    public static void setScore(int newScore) {
        score = newScore;
    }

    /**
     * This method will return the score.
     *
     * PreCondition: None PostCondition: The score has been returned.
     *
     * @return the score
     */
    public static int getScore() {
        return score;
    }

    /**
     * This method will add one point to the score.
     *
     * PreCondition: None PostCondition: One point has been added.
     *
     */
    public static void addOnePoint() throws IOException {
        setScore(score + 1);
        //update the score field
        scoreField.setText(score + "");
        saveHighScore();
        loadHighScore();
    }
    
    /**
     * This method will register that an enemy has been avoided.
     * 
     * PreCondition: None PostCondition: A point has been added and the next
     * enemy has been sent.
     * 
     * @throws IOException 
     */
    public static void avoid() throws IOException {
        if (enemy1.getRectangle().x == 0 && enemy1.getOffScreen() == false && hasLost == false) {
            addOnePoint();
            //to prevent the avoid from registering more than once
            enemy1.setOffScreen(true);
            enemy2.changeGraphics();
            enemy2.setLayoutX(500);
            enemy2.setLayoutY(-220);
            enemy2.stop();//this line and the following line are so the speed will change each time
            enemy2.animation();
            //so the enemies will keep coming
            enemy2.setOffScreen(false);
        }
        if (enemy2.getRectangle().x == 0 && enemy2.getOffScreen() == false && hasLost == false) {
            addOnePoint();
            enemy2.setOffScreen(true);
            enemy1.changeGraphics();
            enemy1.setLayoutX(500);
            enemy1.setLayoutY(220);
            enemy1.stop();
            enemy1.animation();
            enemy1.setOffScreen(false);
        }
    }
    /**
     * This method will load the high score at the beginning of the game.
     * 
     * PreCondition: The game has just started. PostCondition: The high
     * score has been loaded.
     * 
     * @throws IOException 
     */
    public static void loadHighScore() throws IOException {
        try {
            File file = new File("highScore.txt");
            Scanner input = new Scanner(file);
            highScore = input.nextInt();
        } catch (IOException ex1) {

        } catch (Exception ex2) {

        }
        highScoreField.setText(highScore + "");
    }
    /**
     * This method will save the high score to a file.
     * 
     * PreCondition: A new high score has been set. PostCondition: The high
     * score has been saved.
     * 
     * @throws IOException 
     */
    public static void saveHighScore() throws IOException {
        if (score > highScore) {
            try {
                File file = new File("highScore.txt");
                PrintWriter output = new PrintWriter(file);
                output.print(score);
                output.close();
            } catch (IOException ex) {
                System.out.println("Error: Could not save high score");
            }
        }
    }
    
    /**
     * This method will use a random number to determine whether or not the
     * night background is to be used.
     * 
     * PreCondition: The program has just started. PostCondition: The boolean
     * value of whether or not the number is at least 0.5 has been returned.
     * 
     * @return the boolean value of whether or not the number is at least 0.5
     */
    public static boolean nightCheck() {
        double nightNumber = Math.random();
        return nightNumber >= 0.5;
    }

}
