/*
 * This class is for the player.
 */
package kangarooGame;

import javafx.animation.Timeline;
import javafx.animation.KeyFrame;
import javafx.util.Duration;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.awt.Rectangle;

/**
 * Jordan Clay
 */
public class Player {

    private Timeline animation;
    private Timeline downAnimation;
    private double xCenter = 0;
    private double yCenter = 0;
    private boolean hasPeaked = false;
    private Image graphics = new Image("file:player.gif");
    private ImageView graphicsView = new ImageView(graphics);

    public Player() {
    }

    public Player(double xCenter, double yCenter) {
        this.xCenter = xCenter;
        this.yCenter = yCenter;
        graphicsView.setLayoutX(xCenter);
        graphicsView.setLayoutY(yCenter);
    }

    /**
     * This method will set the center x-coordinate to a value.
     *
     * PreCondition: The xCenter variable has been declared. PostCondition: The
     * xCenter variable has been set to a value.
     *
     * @param xCenter - the center x-coordinate
     */
    public void setXCenter(double xCenter) {
        this.xCenter = xCenter;
    }

    /**
     * This method will return the value of the center x-coordinate.
     *
     * PreCondition: The xCenter variable has been set. PostCondition: The value
     * of the center x-coordinate has been returned.
     *
     * @return the value of the center x-coordinate
     */
    public double getXCenter() {
        return this.xCenter;
    }

    /**
     * This method will set the center y-coordinate to a value.
     *
     * PreCondition: The yCenter variable has been declared. PostCondition: The
     * yCenter variable has been set to a value.
     *
     * @param yCenter - the center y-coordinate
     */
    public void setYCenter(double yCenter) {
        this.yCenter = yCenter;
    }

    /**
     * This method will return the value of the center y-coordinate.
     *
     * PreCondition: The yCenter variable has been set. PostCondition: The value
     * of the center y-coordinate has been returned.
     *
     * @return the value of the center y-coordinate
     */
    public double getYCenter() {
        return this.yCenter;
    }

    /**
     * This method will return the ImageView object for the player.
     *
     * PreCondition: None PostCondition: The ImageView object for the player has
     * been returned.
     *
     * @return the ImageView object for the player
     */
    public ImageView getGraphicsView() {
        return graphicsView;
    }

    /**
     * This method will play the animation of the player jumping.
     *
     * PreCondition: None. PostCondition: The animation has been played.
     *
     */
    public void animation() {
        if (graphicsView.getLayoutY() == yCenter) {
            animation = new Timeline(
                    new KeyFrame(Duration.millis(3.0), e -> move()));
            animation.setCycleCount(Timeline.INDEFINITE);
            animation.play();
        }
    }

    /**
     * This method will make the player jump.
     *
     * PreCondition: None PostCondtion: The player is jumping.
     *
     */
    public void move() {
        if (graphicsView.getLayoutY() == 0) {
            hasPeaked = true;
        }
        if (graphicsView.getLayoutY() > 0 && hasPeaked == false) {
            graphicsView.setLayoutY(graphicsView.getLayoutY() - 1);
        }
        if (graphicsView.getLayoutY() < yCenter && hasPeaked == true) {
            graphicsView.setLayoutY(graphicsView.getLayoutY() + 1);
        }
        if (graphicsView.getLayoutY() == yCenter) {
            animation.stop();
            graphicsView.setLayoutY(yCenter);
            hasPeaked = false;
        }
    }
    
    /**
     * This method will return a bounds rectangle for the player.
     * 
     * PreCondition: None PostCondition: The bounds rectangle has been returned.
     * 
     * @return the bounds rectangle
     */
    public Rectangle getRectangle() {
        return new Rectangle((int)graphicsView.getLayoutX(),(int)graphicsView.getLayoutY(),30,40);
    }
    
    /**
     * This method will stop the player animation.
     * 
     * PreCondition: The animation is running. PostCondition: The animation
     * has stopped.
     * 
     */
    public void stop() {
        animation.stop();
    }
    
}
